        # ... (rest of the code as provided in the prompt)
