# Placeholder for chip detector
