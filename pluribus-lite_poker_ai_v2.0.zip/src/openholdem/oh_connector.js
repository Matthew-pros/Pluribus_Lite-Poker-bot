class OhConnector {
  constructor() {
    console.log("OhConnector initialized (Placeholder)");
  }

  executeAction(action) {
    console.log(`Executing action: ${action} (Placeholder)`);
    // Placeholder: Simulate sending action to OpenHoldem
  }
}

export { OhConnector };
