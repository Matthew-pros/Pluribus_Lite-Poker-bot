from sklearn.cluster import MiniBatchKMeans
import numpy as np

class StrategyCompressor:
    # ... (rest of the code remains the same)
